sample readme file
